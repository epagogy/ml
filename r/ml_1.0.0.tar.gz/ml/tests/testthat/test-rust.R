# Tests for Rust backend (engine="ml") and parity with R backends.
# All tests skip_if_not(.rust_available()) — CI without Rust is fine.

# ── Availability ─────────────────────────────────────────────────────────────

test_that(".rust_available() returns logical", {
  result <- ml:::.rust_available()
  expect_type(result, "logical")
  expect_length(result, 1L)
})

# ── Linear (Ridge) ──────────────────────────────────────────────────────────

test_that("Rust linear: fit + predict regression", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- mtcars_split()
  model <- ml_fit(s$train, "mpg", algorithm = "linear", engine = "ml", seed = 42L)
  expect_s3_class(model, "ml_model")
  expect_equal(model$algorithm, "linear")
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
  expect_type(preds, "double")
})

test_that("Rust linear vs R linear parity", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- mtcars_split()
  model_rust <- ml_fit(s$train, "mpg", algorithm = "linear", engine = "ml", seed = 42L)
  model_r    <- ml_fit(s$train, "mpg", algorithm = "linear", engine = "r", seed = 42L)
  preds_rust <- predict(model_rust, newdata = s$valid)
  preds_r    <- predict(model_r, newdata = s$valid)
  expect_equal(preds_rust, preds_r, tolerance = 1e-6)
})

# ── Logistic ────────────────────────────────────────────────────────────────

test_that("Rust logistic: fit + predict classification", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "logistic", engine = "ml", seed = 42L)
  expect_s3_class(model, "ml_model")
  expect_equal(model$algorithm, "logistic")
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
})

test_that("Rust logistic vs R logistic parity (binary)", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  df <- binary_df(100L)
  s <- ml_split(df, "churn", seed = 42L)
  model_rust <- ml_fit(s$train, "churn", algorithm = "logistic", engine = "ml", seed = 42L)
  model_r    <- ml_fit(s$train, "churn", algorithm = "logistic", engine = "r", seed = 42L)
  preds_rust <- predict(model_rust, newdata = s$valid)
  preds_r    <- predict(model_r, newdata = s$valid)
  # Parity: same predictions (may differ slightly due to optimizer)
  agreement <- mean(preds_rust == preds_r)
  expect_true(agreement >= 0.8, info = paste0("Agreement: ", agreement))
})

# ── Decision Tree ───────────────────────────────────────────────────────────

test_that("Rust decision tree: classification fit + predict", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "decision_tree", engine = "ml", seed = 42L)
  expect_s3_class(model, "ml_model")
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
})

test_that("Rust decision tree: regression fit + predict", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- mtcars_split()
  model <- ml_fit(s$train, "mpg", algorithm = "decision_tree", engine = "ml", seed = 42L)
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
  expect_type(preds, "double")
})

test_that("Rust decision tree: explain returns importances", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "decision_tree", engine = "ml", seed = 42L)
  imp <- ml_explain(model)
  expect_s3_class(imp, "ml_explanation")
  expect_true(nrow(imp) > 0L)
})

# ── Random Forest ───────────────────────────────────────────────────────────

test_that("Rust random forest: classification fit + predict", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "random_forest",
                  engine = "ml", seed = 42L)
  expect_s3_class(model, "ml_model")
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
})

test_that("Rust random forest: regression fit + predict", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- mtcars_split()
  model <- ml_fit(s$train, "mpg", algorithm = "random_forest",
                  engine = "ml", seed = 42L)
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
  expect_type(preds, "double")
})

test_that("Rust random forest: explain returns importances", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "random_forest",
                  engine = "ml", seed = 42L)
  imp <- ml_explain(model)
  expect_s3_class(imp, "ml_explanation")
  expect_true(nrow(imp) > 0L)
})

# ── KNN ─────────────────────────────────────────────────────────────────────

test_that("Rust knn: classification fit + predict", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "knn",
                  engine = "ml", seed = 42L, k = 5L)
  expect_s3_class(model, "ml_model")
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
})

test_that("Rust knn: regression fit + predict", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- mtcars_split()
  model <- ml_fit(s$train, "mpg", algorithm = "knn",
                  engine = "ml", seed = 42L, k = 5L)
  preds <- predict(model, newdata = s$valid)
  expect_length(preds, nrow(s$valid))
  expect_type(preds, "double")
})

# ── Engine parameter ────────────────────────────────────────────────────────

test_that("engine='ml' errors when Rust not available", {
  skip_if(ml:::.rust_available(), "Test requires Rust NOT available")
  s <- iris_split()
  expect_error(
    ml_fit(s$train, "Species", algorithm = "logistic", engine = "ml", seed = 42L),
    class = "config_error"
  )
})

test_that("engine='r' forces CRAN backend even when Rust is available", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "logistic", engine = "r", seed = 42L)
  # R logistic engine stores $models list (from .lr_fit)
  expect_true(is.list(model$engine))
  expect_false(ml:::.is_rust_engine(model$engine))
})

test_that("engine='auto' selects Rust when available", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "logistic", engine = "auto", seed = 42L)
  expect_true(ml:::.is_rust_engine(model$engine))
})

# ── predict_proba ───────────────────────────────────────────────────────────

test_that("Rust logistic predict_proba returns valid probabilities", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "logistic", engine = "ml", seed = 42L)
  proba <- ml_predict_proba(model, s$valid)
  expect_true(is.data.frame(proba))
  expect_equal(nrow(proba), nrow(s$valid))
  # Probabilities should be non-negative and rows should sum close to 1
  expect_true(all(as.matrix(proba) >= 0))
})

test_that("Rust random forest predict_proba returns valid probabilities", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "random_forest",
                  engine = "ml", seed = 42L)
  proba <- ml_predict_proba(model, s$valid)
  expect_true(is.data.frame(proba))
  expect_equal(nrow(proba), nrow(s$valid))
})

# ── Serialization (saveRDS / readRDS) ───────────────────────────────────────

test_that("Rust model survives saveRDS/readRDS round-trip", {
  skip_if_not(ml:::.rust_available(), "Rust backend not available")
  s <- iris_split()
  model <- ml_fit(s$train, "Species", algorithm = "random_forest",
                  engine = "ml", seed = 42L)
  preds_before <- predict(model, newdata = s$valid)

  tmp <- tempfile(fileext = ".rds")
  on.exit(unlink(tmp))
  saveRDS(model, tmp)
  loaded <- readRDS(tmp)

  preds_after <- predict(loaded, newdata = s$valid)
  expect_identical(preds_before, preds_after)
})
