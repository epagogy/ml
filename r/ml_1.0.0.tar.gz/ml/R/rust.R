# R wrappers for Rust ml backends.
# Mirrors py/ml/_rust.py — same algorithms, same JSON serialization.
# All functions are internal (dot-prefix). Called by engines.R dispatch.

# ── Cache ────────────────────────────────────────────────────────────────────

.ml_rust_cache <- new.env(parent = emptyenv())
.ml_rust_cache$available <- NULL

# ── Availability ─────────────────────────────────────────────────────────────

#' Check if Rust backend is available (cached).
#' @keywords internal
.rust_available <- function() {
  if (!is.null(.ml_rust_cache$available)) return(.ml_rust_cache$available)
  result <- tryCatch(
    { .Call(wrap__ml_rust_available); TRUE },
    error = function(e) FALSE
  )
  .ml_rust_cache$available <- result
  result
}

# ── Proba reshape helper ────────────────────────────────────────────────────

.rust_proba_to_df <- function(result) {
  # Rust returns list(data=col_major_flat, nrow=n, ncol=k)
  matrix(result$data, nrow = result$nrow, ncol = result$ncol)
}

# ── Linear (Ridge) ──────────────────────────────────────────────────────────

.fit_rust_linear <- function(X, y, alpha = 1.0, sample_weight = NULL) {
  Xm <- as.matrix(X)
  json <- .Call(wrap__ml_rust_linear_fit,
                as.numeric(Xm), nrow(Xm), ncol(Xm),
                as.numeric(y), alpha, sample_weight)
  list(json = json, type = "rust_linear")
}

.predict_rust_linear <- function(engine, X) {
  Xm <- as.matrix(X)
  .Call(wrap__ml_rust_linear_predict,
        engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
}

.coef_rust_linear <- function(engine) {
  # Returns [intercept, coef1, coef2, ...]
  .Call(wrap__ml_rust_linear_coef, engine$json)
}

# ── Logistic (OvR + L-BFGS) ────────────────────────────────────────────────

.fit_rust_logistic <- function(X, y, C = 1.0, max_iter = 1000L,
                               sample_weight = NULL) {
  Xm <- as.matrix(X)
  y_int <- as.integer(y)
  json <- .Call(wrap__ml_rust_logistic_fit,
                as.numeric(Xm), nrow(Xm), ncol(Xm),
                y_int, C, as.integer(max_iter), sample_weight)
  list(json = json, type = "rust_logistic")
}

.predict_rust_logistic <- function(engine, X) {
  Xm <- as.matrix(X)
  .Call(wrap__ml_rust_logistic_predict,
        engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
}

.proba_rust_logistic <- function(engine, X) {
  Xm <- as.matrix(X)
  result <- .Call(wrap__ml_rust_logistic_predict_proba,
                  engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  pm <- .rust_proba_to_df(result)
  as.data.frame(pm)
}

# ── Decision Tree (CART) ────────────────────────────────────────────────────

.fit_rust_tree <- function(X, y, task, seed, max_depth = 500L,
                           min_samples_split = 2L, min_samples_leaf = 1L,
                           sample_weight = NULL) {
  Xm <- as.matrix(X)
  if (task == "classification") {
    y_int <- as.integer(y)
    json <- .Call(wrap__ml_rust_tree_fit_clf,
                  as.numeric(Xm), nrow(Xm), ncol(Xm),
                  y_int,
                  as.integer(max_depth), as.integer(min_samples_split),
                  as.integer(min_samples_leaf), as.integer(seed),
                  sample_weight)
  } else {
    json <- .Call(wrap__ml_rust_tree_fit_reg,
                  as.numeric(Xm), nrow(Xm), ncol(Xm),
                  as.numeric(y),
                  as.integer(max_depth), as.integer(min_samples_split),
                  as.integer(min_samples_leaf), as.integer(seed),
                  sample_weight)
  }
  list(json = json, type = paste0("rust_tree_", task), task = task)
}

.predict_rust_tree <- function(engine, X, task) {
  Xm <- as.matrix(X)
  if (task == "classification") {
    .Call(wrap__ml_rust_tree_predict_clf,
          engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  } else {
    .Call(wrap__ml_rust_tree_predict_reg,
          engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  }
}

.proba_rust_tree <- function(engine, X) {
  Xm <- as.matrix(X)
  result <- .Call(wrap__ml_rust_tree_predict_proba,
                  engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  pm <- .rust_proba_to_df(result)
  as.data.frame(pm)
}

.importances_rust_tree <- function(engine) {
  .Call(wrap__ml_rust_tree_importances, engine$json)
}

# ── Random Forest ───────────────────────────────────────────────────────────

.fit_rust_forest <- function(X, y, task, seed, n_trees = 100L,
                             max_depth = 500L, min_samples_split = 2L,
                             min_samples_leaf = 1L,
                             sample_weight = NULL) {
  Xm <- as.matrix(X)
  if (task == "classification") {
    y_int <- as.integer(y)
    json <- .Call(wrap__ml_rust_forest_fit_clf,
                  as.numeric(Xm), nrow(Xm), ncol(Xm),
                  y_int,
                  as.integer(n_trees), as.integer(max_depth),
                  as.integer(min_samples_split), as.integer(min_samples_leaf),
                  as.integer(seed), sample_weight)
  } else {
    json <- .Call(wrap__ml_rust_forest_fit_reg,
                  as.numeric(Xm), nrow(Xm), ncol(Xm),
                  as.numeric(y),
                  as.integer(n_trees), as.integer(max_depth),
                  as.integer(min_samples_split), as.integer(min_samples_leaf),
                  as.integer(seed), sample_weight)
  }
  list(json = json, type = paste0("rust_forest_", task), task = task)
}

.predict_rust_forest <- function(engine, X, task) {
  Xm <- as.matrix(X)
  if (task == "classification") {
    .Call(wrap__ml_rust_forest_predict_clf,
          engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  } else {
    .Call(wrap__ml_rust_forest_predict_reg,
          engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  }
}

.proba_rust_forest <- function(engine, X) {
  Xm <- as.matrix(X)
  result <- .Call(wrap__ml_rust_forest_predict_proba,
                  engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  pm <- .rust_proba_to_df(result)
  as.data.frame(pm)
}

.importances_rust_forest <- function(engine) {
  .Call(wrap__ml_rust_forest_importances, engine$json)
}

# ── KNN ─────────────────────────────────────────────────────────────────────

.fit_rust_knn <- function(X, y, task, k = 5L) {
  Xm <- as.matrix(X)
  if (task == "classification") {
    y_int <- as.integer(y)
    json <- .Call(wrap__ml_rust_knn_fit_clf,
                  as.numeric(Xm), nrow(Xm), ncol(Xm),
                  y_int, as.integer(k))
  } else {
    json <- .Call(wrap__ml_rust_knn_fit_reg,
                  as.numeric(Xm), nrow(Xm), ncol(Xm),
                  as.numeric(y), as.integer(k))
  }
  list(json = json, type = paste0("rust_knn_", task), task = task)
}

.predict_rust_knn <- function(engine, X, task) {
  Xm <- as.matrix(X)
  if (task == "classification") {
    .Call(wrap__ml_rust_knn_predict_clf,
          engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  } else {
    .Call(wrap__ml_rust_knn_predict_reg,
          engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  }
}

.proba_rust_knn <- function(engine, X) {
  Xm <- as.matrix(X)
  result <- .Call(wrap__ml_rust_knn_predict_proba,
                  engine$json, as.numeric(Xm), nrow(Xm), ncol(Xm))
  pm <- .rust_proba_to_df(result)
  as.data.frame(pm)
}

# ── Rust engine type detection ──────────────────────────────────────────────

.is_rust_engine <- function(engine) {
  is.list(engine) && !is.null(engine$type) && startsWith(engine$type, "rust_")
}
