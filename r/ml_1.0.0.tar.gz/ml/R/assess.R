#' Assess model on held-out test data (do once)
#'
#' The final exam — separate from [ml_evaluate()] to force a conscious choice.
#' Errors if called more than once on the same model. Use `s$test` (not
#' `s$valid`) for the test data.
#'
#' @param model An `ml_model`
#' @param test Test data.frame (use `s$test`). Specify by name for clarity.
#' @returns An object of class `ml_metrics`
#' @export
#' @examples
#' s <- ml_split(iris, "Species", seed = 42)
#' model <- ml_fit(s$train, "Species", seed = 42)
#' verdict <- ml_assess(model, test = s$test)
ml_assess <- function(model, test) {
  .assess_impl(model = model, test = test)
}

.assess_impl <- function(model, test) {
  # Auto-unwrap TuningResult
  if (inherits(model, "ml_tuning_result")) model <- model[["best_model"]]
  if (!inherits(model, "ml_model")) model_error("Expected an ml_model or ml_tuning_result")

  # Increment assess counter FIRST, then check (Python delta P1 #8 — increment-then-check)
  .inc_assess_count(model)
  count <- .get_assess_count(model)
  if (count > 1L) {
    cli::cli_abort(paste0(
      "ml_assess() called ", count,
      " times on same model. Repeated peeking at test data inflates apparent performance."
    ))
  }

  .evaluate_impl(model, test)
}
